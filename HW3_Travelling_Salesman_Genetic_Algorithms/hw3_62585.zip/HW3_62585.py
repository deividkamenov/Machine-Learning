import numpy as np
import random
import operator
import csv
from pathlib import Path


class CordinatePoint:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def distance(self, p):
        dx = abs(self.x - p.x)
        dy = abs(self.y - p.y)
        return np.sqrt((dx ** 2) + (dy ** 2))

    def __repr__(self):
        return "(" + str(self.x) + "," + str(self.y) + ")"


def generate_random_cities(count):
    return [CordinatePoint(x, y) for x, y in
            zip(np.random.randint(-200, 200, size=count), np.random.randint(-200, 200, size=count))]


class CalulateFitness:
    def __init__(self, route):
        self.route = route
        self.distance = 0
        self.ft = 0.0

    def find_route_distance(self):
        if self.distance == 0:
            path_distance = sum(
                from_city.distance(to_city) for from_city, to_city in zip(self.route, self.route[1:] + [self.route[0]]))
            self.distance = path_distance
        return self.distance

    # this function is used to calculate the fitness of the route fintess of route means 1/distance of the route
    def fitness_evaluation(self):
        if self.ft == 0:
            self.ft = 1 / float(self.find_route_distance())
        return self.ft


def initial_route(cityList):
    return random.sample(cityList, len(cityList))  # random sample is used to create a random routesample means


def rand_start_values(routesNumber, pointsL):
    routes = []
    for i in range(routesNumber):
        routes.append(initial_route(pointsL))
    return routes


# this is a function that allows us to find the best individuates in the population
def selection(population_ranked, best_route_size):
    selectionResults = []

    # the fitness value is the second element of each touple in pop_ranked
    totalFitness = sum(ind[1] for ind in population_ranked)
    # Calculates the cumulative probabilities for each route. It divides each route's fitness by the total fitness
    # and then calculates the cumulative sum
    # the route comulative means that we are selecting the routes with the highest fitness
    cumulative_probabilities = np.cumsum([ind[1] / totalFitness for ind in population_ranked])

    # cumsum is a function that is used to calculate the cumulative sum of the elements along a given axis
    for i in range(best_route_size):
        selectionResults.append(population_ranked[i][0])  # the first element in a touple is the index of the route

    # for the rest of the routes we are using the cumulative probabilities
    for i in range(len(population_ranked) - best_route_size):
        pick = random.random()
        for j in range(len(population_ranked)):
            if pick <= cumulative_probabilities[j]:
                selectionResults.append(population_ranked[j][0])
                break

    return selectionResults


def compare_routes(initialRoutes):
    fitnessResults = {}
    for i in range(0, len(initialRoutes)):
        fitnessResults[i] = CalulateFitness(initialRoutes[i]).fitness_evaluation()

    return sorted(fitnessResults.items(), key=operator.itemgetter(1), reverse=True)


# this funnction is used to create a mating pool in other words
def select_best_route(population, selectionResults):
    return [population[index] for index in selectionResults]


def crossover(parent1,
              parent2):  # this is the crossover function which is used to crossover two parents to create a child
    geneA, geneB = random.randint(0, len(parent1) - 1), random.randint(0, len(parent1) - 1)
    startGene, endGene = min(geneA, geneB), max(geneA, geneB)

    # here we are creating a child by taking a random part of the first parent and then we are adding the rest of the cities from the second parent
    child1 = parent1[startGene:endGene]
    child2 = [item for item in parent2 if item not in child1]

    return child1 + child2


def crossover_population(list_population, best_route_size):
    # the difference betweeen poop and list_population is that the selected_individuals are the individuals that are selected from the population and the pool is the individuals that are selected from the selected_individuals

    length = len(list_population) - best_route_size
    pool = random.sample(list_population, len(list_population))
    children = [list_population[i] for i in range(best_route_size)]

    # this loop is used to create the children by using the crossover_parents function

    for i in range(0, length):
        child = crossover(pool[i], pool[len(list_population) - i - 1])
        children.append(child)
    return children


def mutate(individual, mutation_rate):
    # this loop iterates through the individuals and if the random number is less than the rate of mutation then it swaps the genes
    for swapped in range(len(individual)):
        if (random.random() < mutation_rate):
            to_swap_with = int(random.random() * len(individual))

            individual[swapped], individual[to_swap_with] = individual[to_swap_with], individual[swapped]

    return individual


def mutate_population(population, mutation_rate):
    return [mutate(individual, mutation_rate) for individual in population]


def nextGeneration(currentGen, best_route_size, mutation_rate):
    population_ranked = compare_routes(currentGen)
    selection_results = selection(population_ranked, best_route_size)
    list_population = select_best_route(currentGen, selection_results)
    children = crossover_population(list_population, best_route_size)
    next_generation = mutate_population(children, mutation_rate)
    return next_generation


def select_random_indexes(population):
    return sorted(random.sample(range(1, len(population) - 1), 8))


def run_genetic_algorithm(points_list, routes_count, best_route_size, mutation_rate, generations):
    list_population = []
    current_population = rand_start_values(routes_count, points_list)  # this is the initial population
    list_population.append(current_population)  #
    print(str(int(1 / compare_routes(current_population)[0][1])))  # this is the best route in the initial population

    # this loop is used to create the next generations
    for i in range(0, generations):
        current_population = nextGeneration(current_population, best_route_size, mutation_rate)
        list_population.append(current_population)

    # this loop is used to print the best route in each generation
    for index in select_random_indexes(list_population):
        print(str(int(1 / compare_routes(list_population[index])[0][1])))

    print(str(int(1 / compare_routes(current_population)[0][1])))  # this is the best route in the last generation
    index_best_route = compare_routes(current_population)[0][
        0]  # this is the index of the best route in the last generation
    best_route = current_population[index_best_route]
    return best_route


def read_points_and_names(file_path_names, file_path_coordinates):
    points_dict = {}

    with open(file_path_names, 'r') as file_names, open(file_path_coordinates, 'r') as file_coordinates:
        names_reader = csv.reader(file_names, delimiter=',')
        coordinates_reader = csv.reader(file_coordinates, delimiter=',')

        for name_row, coordinates_row in zip(names_reader, coordinates_reader):
            name = name_row[0]
            x, y = map(float, coordinates_row)
            point = CordinatePoint(x, y)

            points_dict[name] = point

    return points_dict


def print_city_names(coordinates_list, points_and_names_dict):
    for coordinates in coordinates_list:
        point = CordinatePoint(coordinates.x, coordinates.y)
        # Find the closest point in the dictionary
        closest_name = min(points_and_names_dict, key=lambda k: point.distance(points_and_names_dict[k]))

        print(closest_name, end=", ")
        print()


def main():
    to_read_from_file = True  # Change this to test with UK cities
    if to_read_from_file == True:
        points_and_names_dict = read_points_and_names(Path(".\\UK_TSP\\uk12_name.csv"), Path(".\\UK_TSP\\uk12_xy.csv"))
        # points_and_names_dict = read_points_and_names(Path(
        #     "C:\\FMI Sofia UNI programming\\Inteligent Systems\\ALL HOMEWORKS\\hmework3_deivid\\UK_TSP\\uk12_name.csv"),
        #     Path(
        #         "C:\\FMI Sofia UNI programming\\Inteligent Systems\\ALL HOMEWORKS\\hmework3_deivid\\UK_TSP\\uk12_xy.csv"))

        points = list(points_and_names_dict.values())
        coordinates_list = run_genetic_algorithm(points_list=points, routes_count=100, best_route_size=20,
                                                 mutation_rate=0.01, generations=500)
        print_city_names(coordinates_list, points_and_names_dict)
    else:
        count = int(input())
        points = generate_random_cities(count)
        run_genetic_algorithm(points_list=points, routes_count=100, best_route_size=20, mutation_rate=0.01,
                              generations=500)


if __name__ == "__main__": main()
